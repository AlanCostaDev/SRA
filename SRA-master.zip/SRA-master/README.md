# SRA
Sistema Voltado para controle de refeitorio em instituição de ensino.

  1 - Cadasto de Alunos
  
  2 - Cadastro de Funcionarios
  
  3 - Tela de Conferencia- de pedido("Confima se o aluno fez solicitação para poder entra na fila")
  
  4 - Tela Relatorio de pedidos( informa quantidades de alunos e lista de alunos que solicitaram a refeição)
