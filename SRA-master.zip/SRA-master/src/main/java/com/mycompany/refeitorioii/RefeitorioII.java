/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.refeitorioii;

import com.mycompany.view.TelaInicial;
import static java.awt.Frame.MAXIMIZED_BOTH;

/**
 *
 * @author alan
 */
public class RefeitorioII {

    public static void main(String[] args) {


          
        
     TelaInicial log= new TelaInicial();
     log.setVisible(true);
     log.setExtendedState(MAXIMIZED_BOTH);
        
    }
}
