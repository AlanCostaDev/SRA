/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.refeitorioii;

import com.mycompany.view.LoginAluno;


/**
 *
 * @author alan
 */
public class RefeitorioII {

    public static void main(String[] args) {
        
          
      LoginAluno log= new LoginAluno();
      log.setVisible(true);
        
    }
}
